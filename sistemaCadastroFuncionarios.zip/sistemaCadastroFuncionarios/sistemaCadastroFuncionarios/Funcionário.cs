using System.Data;
using static sistemaCadastroFuncionarios.CarregarSetorClass;

namespace sistemaCadastroFuncionarios
{
    public partial class Funcion�rio : Form
    {
        public Funcion�rio()
        {
            InitializeComponent();
        }

        private void CarregarSetores()
        {
            cbxSetor.Items.Clear();
            List<Setor> setores = CarregarSetorClass.ListarSetores();

            foreach (Setor setor in setores)
            {
                cbxSetor.Items.Add(setor.Nome);
            }
        }

        private void Funcion�rio_Load(object sender, EventArgs e)
        {
            CarregarSetores();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {


                if (string.IsNullOrWhiteSpace(txtNome.Text) ||
                    string.IsNullOrWhiteSpace(mtxtCPF.Text) ||
                    dtpData.Value > DateTime.Today ||
                    string.IsNullOrWhiteSpace(txtCargo.Text) ||
                    string.IsNullOrWhiteSpace(txtSalario.Text) ||
                    !decimal.TryParse(txtSalario.Text, out _) ||
                    (rbtnMasculino.Checked == false && rbtnFeminino.Checked == false) ||
                    string.IsNullOrWhiteSpace(cbxSetor.Text) || cbxSetor.SelectedIndex == -1)
                {
                    MessageBox.Show("Preencha todos os campos corretamente!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;

                }
                else
                {
                    mtxtCPF.TextMaskFormat = MaskFormat.IncludePromptAndLiterals;
                    Funcion�riosClass funcionario = new Funcion�riosClass();
                    funcionario.Nome = txtNome.Text;
                    funcionario.Cpf = mtxtCPF.Text;
                    funcionario.DataNascimento = dtpData.Value;
                    funcionario.Cargo = txtCargo.Text;
                    funcionario.Setor = cbxSetor.Text;
                    funcionario.Salario = decimal.Parse(txtSalario.Text);
                    funcionario.Sexo = rbtnMasculino.Checked ? "Masculino" : (rbtnFeminino.Checked ? "Feminino" : "");

                    if (funcionario.Cadastrar())
                    {
                        MessageBox.Show("Funcion�rio cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txtNome.Clear();
                        mtxtCPF.Clear();
                        txtCargo.Clear();
                        txtSalario.Clear();
                        txtNome.Clear();
                        cbxSetor.SelectedIndex = -1;
                        rbtnMasculino.Checked = false;
                        rbtnFeminino.Checked = false;
                        dtpData.Value = DateTime.Today;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao cadastrar o funcion�rio. Verifique os dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Ocorreu um erro ao cadastrar funcion�rio\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {


                if (string.IsNullOrWhiteSpace(txtNome.Text) ||
                    string.IsNullOrWhiteSpace(mtxtCPF.Text) ||
                    dtpData.Value > DateTime.Today ||
                    string.IsNullOrWhiteSpace(txtCargo.Text) ||
                    string.IsNullOrWhiteSpace(txtSalario.Text) ||
                    !decimal.TryParse(txtSalario.Text, out _) ||
                    (rbtnMasculino.Checked == false && rbtnFeminino.Checked == false) ||
                    string.IsNullOrWhiteSpace(cbxSetor.Text) || cbxSetor.SelectedIndex == -1)
                {
                    MessageBox.Show("Preencha todos os campos corretamente!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;

                }
                else
                {
                    mtxtCPF.TextMaskFormat = MaskFormat.IncludePromptAndLiterals;
                    Funcion�riosClass funcionario = new Funcion�riosClass();
                    funcionario.Nome = txtNome.Text;
                    funcionario.Cpf = mtxtCPF.Text;
                    funcionario.DataNascimento = dtpData.Value;
                    funcionario.Cargo = txtCargo.Text;
                    funcionario.Setor = cbxSetor.Text;
                    funcionario.Salario = decimal.Parse(txtSalario.Text);
                    funcionario.Sexo = rbtnMasculino.Checked ? "Masculino" : (rbtnFeminino.Checked ? "Feminino" : "");

                    if (funcionario.Cadastrar())
                    {
                        MessageBox.Show("Funcion�rio editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        txtNome.Clear();
                        mtxtCPF.Clear();
                        txtCargo.Clear();
                        txtSalario.Clear();
                        txtNome.Clear();
                        cbxSetor.SelectedIndex = -1;
                        rbtnMasculino.Checked = false;
                        rbtnFeminino.Checked = false;
                        dtpData.Value = DateTime.Today;
                    }
                    else
                    {
                        MessageBox.Show("Erro ao editar funcin�rio. Verifique os dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("");
            }

        }

        private void btnListarTodos_Click(object sender, EventArgs e)
        {
            Funcion�riosClass funcionarios = new Funcion�riosClass();
            funcionarios.ListarTodosFuncionarios(dataGridFuncionario);
        }

        private void dataGridFuncionario_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow linha = dataGridFuncionario.Rows[e.RowIndex];

                    //txtID.Text = linha.Cells["id"].Value.ToString();
                    // txtNome.Text = linha.Cells["nome"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar funcion�rios: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
