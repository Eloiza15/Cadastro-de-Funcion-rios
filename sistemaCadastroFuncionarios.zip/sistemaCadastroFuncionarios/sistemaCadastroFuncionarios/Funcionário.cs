namespace sistemaCadastroFuncionarios
{
    public partial class Funcion�rio : Form
    {
        public Funcion�rio()
        {
            InitializeComponent();
        }
    }
}
