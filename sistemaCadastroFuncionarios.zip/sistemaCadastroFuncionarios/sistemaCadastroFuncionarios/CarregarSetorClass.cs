﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaCadastroFuncionarios
{
    public class CarregarSetorClass
    {
        public class Setor
        {
            public int Id { get; set; }
            public string Nome { get; set; }
        }

        public static List<Setor> ListarSetores()
        {
            List<Setor> setores = new List<Setor>();
            ConexaoBDClass conexaoBD = new ConexaoBDClass();
            MySqlConnection conexao = conexaoBD.Conectar();

            string query = "SELECT * FROM setor";

            MySqlCommand cmd = new MySqlCommand(query, conexao);
            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                setores.Add(new Setor
                {
                    Id = int.Parse(reader["id"].ToString()),
                    Nome = reader["nome"].ToString()

                });
            }

            conexao.Close();
            return setores;
        }
    }
}
