﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemaCadastroFuncionarios
{
    public class ConexaoBDClass
    {
            //String de Conexão
            private string conexaoBanco = "Server=localhost; Database=gestorEmpresa; Uid=root; Pwd='';";

            public MySqlConnection Conectar()
            {
                MySqlConnection conexao = new MySqlConnection(conexaoBanco);
                conexao.Open();
                return conexao;
            }
    }
}
