﻿namespace sistemaCadastroFuncionarios
{
    partial class Funcionário
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNomeFuncionario = new Label();
            txtNomeFuncionario = new TextBox();
            dataGridFuncionario = new DataGridView();
            lblID = new Label();
            txtID = new TextBox();
            lblNome = new Label();
            txtNome = new TextBox();
            lblData = new Label();
            dtpData = new DateTimePicker();
            lblCargo = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionario).BeginInit();
            SuspendLayout();
            // 
            // lblNomeFuncionario
            // 
            lblNomeFuncionario.AutoSize = true;
            lblNomeFuncionario.Location = new Point(21, 23);
            lblNomeFuncionario.Name = "lblNomeFuncionario";
            lblNomeFuncionario.Size = new Size(365, 29);
            lblNomeFuncionario.TabIndex = 0;
            lblNomeFuncionario.Text = "Digite o Nome do Funcionário:";
            // 
            // txtNomeFuncionario
            // 
            txtNomeFuncionario.Location = new Point(392, 20);
            txtNomeFuncionario.Name = "txtNomeFuncionario";
            txtNomeFuncionario.Size = new Size(485, 35);
            txtNomeFuncionario.TabIndex = 1;
            // 
            // dataGridFuncionario
            // 
            dataGridFuncionario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridFuncionario.Location = new Point(21, 75);
            dataGridFuncionario.Name = "dataGridFuncionario";
            dataGridFuncionario.RowHeadersWidth = 62;
            dataGridFuncionario.Size = new Size(856, 225);
            dataGridFuncionario.TabIndex = 2;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Location = new Point(21, 324);
            lblID.Name = "lblID";
            lblID.Size = new Size(44, 29);
            lblID.TabIndex = 3;
            lblID.Text = "ID:";
            // 
            // txtID
            // 
            txtID.Location = new Point(136, 321);
            txtID.Name = "txtID";
            txtID.Size = new Size(150, 35);
            txtID.TabIndex = 3;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(21, 373);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(86, 29);
            lblNome.TabIndex = 4;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(136, 370);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(741, 35);
            txtNome.TabIndex = 4;
            // 
            // lblData
            // 
            lblData.AutoSize = true;
            lblData.Location = new Point(21, 420);
            lblData.Name = "lblData";
            lblData.Size = new Size(71, 29);
            lblData.TabIndex = 5;
            lblData.Text = "Data:";
            // 
            // dtpData
            // 
            dtpData.Location = new Point(136, 415);
            dtpData.Name = "dtpData";
            dtpData.Size = new Size(300, 35);
            dtpData.TabIndex = 5;
            // 
            // lblCargo
            // 
            lblCargo.AutoSize = true;
            lblCargo.Location = new Point(479, 420);
            lblCargo.Name = "lblCargo";
            lblCargo.Size = new Size(89, 29);
            lblCargo.TabIndex = 6;
            lblCargo.Text = "Cargo:";
            // 
            // Funcionário
            // 
            AutoScaleDimensions = new SizeF(15F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(909, 552);
            Controls.Add(lblCargo);
            Controls.Add(dtpData);
            Controls.Add(lblData);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(txtID);
            Controls.Add(lblID);
            Controls.Add(dataGridFuncionario);
            Controls.Add(txtNomeFuncionario);
            Controls.Add(lblNomeFuncionario);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Funcionário";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Funcionário";
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionario).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomeFuncionario;
        private TextBox txtNomeFuncionario;
        private DataGridView dataGridFuncionario;
        private Label lblID;
        private TextBox txtID;
        private Label lblNome;
        private TextBox txtNome;
        private Label lblData;
        private DateTimePicker dtpData;
        private Label lblCargo;
    }
}
