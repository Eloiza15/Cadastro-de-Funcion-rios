﻿namespace sistemaCadastroFuncionarios
{
    partial class Funcionário
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNomeFuncionario = new Label();
            txtNomeFuncionario = new TextBox();
            dataGridFuncionario = new DataGridView();
            lblID = new Label();
            txtID = new TextBox();
            lblNome = new Label();
            txtNome = new TextBox();
            lblData = new Label();
            dtpData = new DateTimePicker();
            lblCargo = new Label();
            txtCargo = new TextBox();
            lblSalario = new Label();
            txtSalario = new TextBox();
            gbxSexo = new GroupBox();
            rbtnFeminino = new RadioButton();
            rbtnMasculino = new RadioButton();
            lblCPF = new Label();
            mtxtCPF = new MaskedTextBox();
            lblSetor = new Label();
            cbxSetor = new ComboBox();
            btnCadastrar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            btnListarTodos = new Button();
            btnListarPorSetor = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionario).BeginInit();
            gbxSexo.SuspendLayout();
            SuspendLayout();
            // 
            // lblNomeFuncionario
            // 
            lblNomeFuncionario.AutoSize = true;
            lblNomeFuncionario.Location = new Point(21, 23);
            lblNomeFuncionario.Name = "lblNomeFuncionario";
            lblNomeFuncionario.Size = new Size(242, 19);
            lblNomeFuncionario.TabIndex = 0;
            lblNomeFuncionario.Text = "Digite o Nome do Funcionário:";
            // 
            // txtNomeFuncionario
            // 
            txtNomeFuncionario.Location = new Point(288, 20);
            txtNomeFuncionario.Name = "txtNomeFuncionario";
            txtNomeFuncionario.Size = new Size(485, 26);
            txtNomeFuncionario.TabIndex = 1;
            // 
            // dataGridFuncionario
            // 
            dataGridFuncionario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridFuncionario.Location = new Point(21, 75);
            dataGridFuncionario.Name = "dataGridFuncionario";
            dataGridFuncionario.RowHeadersWidth = 62;
            dataGridFuncionario.Size = new Size(1133, 225);
            dataGridFuncionario.TabIndex = 2;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Location = new Point(21, 324);
            lblID.Name = "lblID";
            lblID.Size = new Size(31, 19);
            lblID.TabIndex = 3;
            lblID.Text = "ID:";
            // 
            // txtID
            // 
            txtID.Location = new Point(136, 321);
            txtID.Name = "txtID";
            txtID.Size = new Size(150, 26);
            txtID.TabIndex = 3;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(21, 373);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(60, 19);
            lblNome.TabIndex = 4;
            lblNome.Text = "Nome:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(136, 370);
            txtNome.MaxLength = 200;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(741, 26);
            txtNome.TabIndex = 4;
            // 
            // lblData
            // 
            lblData.AutoSize = true;
            lblData.Location = new Point(21, 420);
            lblData.Name = "lblData";
            lblData.Size = new Size(50, 19);
            lblData.TabIndex = 5;
            lblData.Text = "Data:";
            // 
            // dtpData
            // 
            dtpData.Location = new Point(136, 415);
            dtpData.Name = "dtpData";
            dtpData.Size = new Size(300, 26);
            dtpData.TabIndex = 5;
            // 
            // lblCargo
            // 
            lblCargo.AutoSize = true;
            lblCargo.Location = new Point(478, 415);
            lblCargo.Name = "lblCargo";
            lblCargo.Size = new Size(62, 19);
            lblCargo.TabIndex = 6;
            lblCargo.Text = "Cargo:";
            // 
            // txtCargo
            // 
            txtCargo.Location = new Point(572, 412);
            txtCargo.MaxLength = 100;
            txtCargo.Name = "txtCargo";
            txtCargo.Size = new Size(305, 26);
            txtCargo.TabIndex = 6;
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(21, 467);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(68, 19);
            lblSalario.TabIndex = 7;
            lblSalario.Text = "Salário:";
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(136, 464);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(300, 26);
            txtSalario.TabIndex = 7;
            // 
            // gbxSexo
            // 
            gbxSexo.Controls.Add(rbtnFeminino);
            gbxSexo.Controls.Add(rbtnMasculino);
            gbxSexo.Location = new Point(21, 509);
            gbxSexo.Name = "gbxSexo";
            gbxSexo.Size = new Size(242, 72);
            gbxSexo.TabIndex = 8;
            gbxSexo.TabStop = false;
            gbxSexo.Text = "Sexo:";
            // 
            // rbtnFeminino
            // 
            rbtnFeminino.AutoSize = true;
            rbtnFeminino.Location = new Point(6, 30);
            rbtnFeminino.Name = "rbtnFeminino";
            rbtnFeminino.Size = new Size(98, 23);
            rbtnFeminino.TabIndex = 0;
            rbtnFeminino.TabStop = true;
            rbtnFeminino.Text = "Feminino";
            rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // rbtnMasculino
            // 
            rbtnMasculino.AutoSize = true;
            rbtnMasculino.Location = new Point(115, 30);
            rbtnMasculino.Name = "rbtnMasculino";
            rbtnMasculino.Size = new Size(105, 23);
            rbtnMasculino.TabIndex = 1;
            rbtnMasculino.TabStop = true;
            rbtnMasculino.Text = "Masculino";
            rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // lblCPF
            // 
            lblCPF.AutoSize = true;
            lblCPF.Location = new Point(906, 415);
            lblCPF.Name = "lblCPF";
            lblCPF.Size = new Size(48, 19);
            lblCPF.TabIndex = 9;
            lblCPF.Text = "CPF:";
            // 
            // mtxtCPF
            // 
            mtxtCPF.Location = new Point(982, 412);
            mtxtCPF.Mask = "000.000.000-00";
            mtxtCPF.Name = "mtxtCPF";
            mtxtCPF.Size = new Size(172, 26);
            mtxtCPF.TabIndex = 8;
            // 
            // lblSetor
            // 
            lblSetor.AutoSize = true;
            lblSetor.Location = new Point(906, 471);
            lblSetor.Name = "lblSetor";
            lblSetor.Size = new Size(56, 19);
            lblSetor.TabIndex = 10;
            lblSetor.Text = "Setor:";
            // 
            // cbxSetor
            // 
            cbxSetor.FormattingEnabled = true;
            cbxSetor.Items.AddRange(new object[] { "Recursos Humanos", "Financeiro", "TI", "Marketing", "Vendas", "Logística" });
            cbxSetor.Location = new Point(982, 464);
            cbxSetor.Name = "cbxSetor";
            cbxSetor.Size = new Size(172, 27);
            cbxSetor.TabIndex = 10;
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(136, 605);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(173, 30);
            btnCadastrar.TabIndex = 11;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(453, 605);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(173, 30);
            btnEditar.TabIndex = 12;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(781, 605);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(173, 30);
            btnExcluir.TabIndex = 13;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // btnListarTodos
            // 
            btnListarTodos.Location = new Point(346, 525);
            btnListarTodos.Name = "btnListarTodos";
            btnListarTodos.Size = new Size(156, 51);
            btnListarTodos.TabIndex = 14;
            btnListarTodos.Text = "Listar Todos Funcionários";
            btnListarTodos.UseVisualStyleBackColor = true;
            // 
            // btnListarPorSetor
            // 
            btnListarPorSetor.Location = new Point(572, 525);
            btnListarPorSetor.Name = "btnListarPorSetor";
            btnListarPorSetor.Size = new Size(172, 51);
            btnListarPorSetor.TabIndex = 15;
            btnListarPorSetor.Text = "Listar Funcionários por Setor";
            btnListarPorSetor.UseVisualStyleBackColor = true;
            // 
            // Funcionário
            // 
            AutoScaleDimensions = new SizeF(10F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1176, 666);
            Controls.Add(btnListarPorSetor);
            Controls.Add(btnListarTodos);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnCadastrar);
            Controls.Add(cbxSetor);
            Controls.Add(lblSetor);
            Controls.Add(mtxtCPF);
            Controls.Add(lblCPF);
            Controls.Add(gbxSexo);
            Controls.Add(txtSalario);
            Controls.Add(lblSalario);
            Controls.Add(txtCargo);
            Controls.Add(lblCargo);
            Controls.Add(dtpData);
            Controls.Add(lblData);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(txtID);
            Controls.Add(lblID);
            Controls.Add(dataGridFuncionario);
            Controls.Add(txtNomeFuncionario);
            Controls.Add(lblNomeFuncionario);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Funcionário";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Funcionário";
            ((System.ComponentModel.ISupportInitialize)dataGridFuncionario).EndInit();
            gbxSexo.ResumeLayout(false);
            gbxSexo.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomeFuncionario;
        private TextBox txtNomeFuncionario;
        private DataGridView dataGridFuncionario;
        private Label lblID;
        private TextBox txtID;
        private Label lblNome;
        private TextBox txtNome;
        private Label lblData;
        private DateTimePicker dtpData;
        private Label lblCargo;
        private TextBox txtCargo;
        private Label lblSalario;
        private TextBox txtSalario;
        private GroupBox gbxSexo;
        private RadioButton rbtnFeminino;
        private RadioButton rbtnMasculino;
        private Label lblCPF;
        private MaskedTextBox mtxtCPF;
        private Label lblSetor;
        private ComboBox cbxSetor;
        private Button btnCadastrar;
        private Button btnEditar;
        private Button btnExcluir;
        private Button btnListarTodos;
        private Button btnListarPorSetor;
    }
}
