﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemaCadastroFuncionarios
{
    public class FuncionáriosClass
    {
        //Atributos
        private int id;
        private string nome;
        private string cpf;
        private DateTime dataNascimento;
        private string cargo;
        private string setor;
        private decimal salario;
        private string sexo;

        //Métodos Get e Set
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public DateTime DataNascimento
        {
            get { return dataNascimento; }
            set { dataNascimento = value; }
        }
        public string Cargo
        {
            get { return cargo; }
            set { cargo = value; }
        }
        public string Setor
        {
            get { return setor; }
            set { setor = value; }
        }
        public decimal Salario
        {
            get { return salario; }
            set { salario = value; }
        }
        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        //Método de Cadastrar Funcionário
        public bool Cadastrar()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                {
                    string inserir = "INSERT INTO funcionarios (nome, cpf, data_nascimento, cargo, setor, salario, sexo) " +
                 "VALUES (@nome, @cpf, @data_nascimento, @cargo, @setor, @salario, @sexo);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@data_nascimento", DataNascimento.ToString("yyyy-MM-dd"));
                    comando.Parameters.AddWithValue("@cargo", Cargo);
                    comando.Parameters.AddWithValue("@setor", Setor);
                    comando.Parameters.AddWithValue("@salario", Salario);
                    comando.Parameters.AddWithValue("@sexo", Sexo);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao inserir funcionário " + ex.Message, "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        //Método de Editar Funcionário
        public bool Editar()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                {
                    string atualizar = "UPDATE funcionarios SET nome = @nome, cpf = @cpf, data_nascimento = @data_nascimento, cargo = @cargo, setor = @setor, salario = @salario, sexo = @sexo WHERE id = @id";

                    MySqlCommand comando = new MySqlCommand(atualizar, conexaoBanco);
                    comando.Parameters.AddWithValue("@id", Id);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@data_nascimento", DataNascimento.ToString("yyyy-MM-dd"));
                    comando.Parameters.AddWithValue("@cargo", Cargo);
                    comando.Parameters.AddWithValue("@setor", Setor);
                    comando.Parameters.AddWithValue("@salario", Salario);
                    comando.Parameters.AddWithValue("@sexo", Sexo);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao editar funcionário " + ex.Message, "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        //Método de Listar Todos Funcionários
        public bool ListarTodosFuncionarios(DataGridView dataGrid)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBDClass().Conectar())
                {
                    string listar = "SELECT * FROM funcionarios";
                    MySqlCommand comando = new MySqlCommand(listar, conexao);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    dataGrid.AllowUserToAddRows = false;
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGrid.AutoResizeColumns();
                    dataGrid.ClearSelection();

                    if (dataGrid.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar funcionários: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        //Método de Excluir Funcionário
        public bool Excluir(int id)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBDClass().Conectar())
                {
                    string excluir = "DELETE FROM funcionarios WHERE id = @id;";

                    MySqlCommand comando = new MySqlCommand(excluir, conexaoBanco);
                    comando.Parameters.AddWithValue("@id", id); 

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true; 
                    }
                    else
                    {
                        return false; 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir funcionário: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false; 
            }
        }

        //Método Listar Funcionario por Nome
        public DataTable ListarFuncionariosPorNome(DataGridView dataGrid, string nome)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBDClass().Conectar())
                {
                    string listar = "SELECT * FROM funcionarios WHERE nome LIKE @nome";
                    MySqlCommand comando = new MySqlCommand(listar, conexao);
                    comando.Parameters.AddWithValue("@nome", "%" + nome + "%");

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    dataGrid.AllowUserToAddRows = false;
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGrid.AutoResizeColumns();
                    dataGrid.ClearSelection();

                    return tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar funcionários: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

    }
}
